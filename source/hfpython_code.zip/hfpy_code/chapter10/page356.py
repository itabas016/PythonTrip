print('Content-type: text/plain\n')

print('Hello from Head First Python on GAE!')

