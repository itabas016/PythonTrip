from distutils.core import setup


setup(
    name='nester',
    version='1.0.0',
    author='arthor',
    author_email="arthor.cui@gmail.com",
    url='https://github.com/ArthorCui/PythonTrip/',
    description='A simple printer of nested lists',
)